# Parallax Section

A Pen created on CodePen.io. Original URL: [https://codepen.io/tak-dcxi/pen/rNEaqMJ](https://codepen.io/tak-dcxi/pen/rNEaqMJ).

